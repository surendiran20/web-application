package RMS;

public class Product {
    private int productId;
    private String productName;
    private String productDescription;
    private double productPrice;
    private int productQuantity;

    // Constructor
    public Product(int productId, String productName, String productDescription, double productPrice, int productQuantity) {
        this.productId = productId;
        this.productName = productName;
        this.productDescription = productDescription;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
    }

    // Getters and Setters
    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

    // Method to update the product quantity after an order is placed
    public void reduceQuantity(int quantity) {
        if (productQuantity >= quantity) {
            this.productQuantity -= quantity;
        } else {
            System.out.println("Not enough stock available.");
        }
    }

    // Method to increase the product quantity (e.g., after restocking)
    public void increaseQuantity(int quantity) {
        this.productQuantity += quantity;
    }

    // Method to display product information
    public void displayProductInfo() {
        System.out.println("Product ID: " + productId);
        System.out.println("Product Name: " + productName);
        System.out.println("Product Description: " + productDescription);
        System.out.println("Price: $" + productPrice);
        System.out.println("Available Quantity: " + productQuantity);
    }

    @Override
    public String toString() {
        return "Product ID: " + productId + ", Name: " + productName + ", Price: $" + productPrice + ", Available Quantity: " + productQuantity;
    }
}


