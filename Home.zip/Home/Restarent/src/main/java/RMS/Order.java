package RMS;

public class Order {
    private int orderId;
    private String itemName;
    private int quantity;
    private String customerName;
    private String address;

    // Constructor
    public Order(int orderId, String itemName, int quantity, String customerName, String address) {
        this.orderId = orderId;
        this.itemName = itemName;
        this.quantity = quantity;
        this.customerName = customerName;
        this.address = address;
    }

    // Getters and setters
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Order ID: " + orderId + ", Item: " + itemName + ", Quantity: " + quantity + ", Customer: " + customerName + ", Address: " + address;
    }
}

