package RMS;

import java.awt.*;
import java.awt.event.*;

public class ManageProductFrame extends Frame {

    public ManageProductFrame() {
        setTitle("Manage Products");
        setSize(400, 300);
        setLayout(new FlowLayout());

        // Add content to manage products
        Label label = new Label("Manage Your Products");
        add(label);

        // Close button to return to HomeFrame
        Button closeButton = new Button("Close");
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);  // Close the current frame
            }
        });
        add(closeButton);

        // Handle window close event
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                setVisible(false);  // Hide the current frame
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new ManageProductFrame();
    }
}
