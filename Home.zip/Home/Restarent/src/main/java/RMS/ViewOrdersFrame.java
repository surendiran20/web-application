package RMS;

import java.awt.*;
import java.awt.event.*;

public class ViewOrdersFrame extends Frame {

    public ViewOrdersFrame() {
        setTitle("View Orders");
        setSize(400, 300);
        setLayout(new FlowLayout());

        // Add content to view orders
        Label label = new Label("View Orders Here");
        add(label);

        // Close button to return to HomeFrame
        Button closeButton = new Button("Close");
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);  // Close the current frame
            }
        });
        add(closeButton);

        // Handle window close event
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                setVisible(false);  // Hide the current frame
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new ViewOrdersFrame();
    }
}

