package RMS;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdminDao {
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/food_order_system"; // Change this URL as per your setup
    private static final String DB_USERNAME = "root";  // Your DB username
    private static final String DB_PASSWORD = "cse23";      // Your DB password

    // Method to establish the database connection
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
    }

    // Method to fetch all orders from the database
    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM orders"; // Assuming the table name is 'orders'

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            // Process the result set and create Order objects
            while (rs.next()) {
                int orderId = rs.getInt("order_id");
                String itemName = rs.getString("item_name");
                int quantity = rs.getInt("quantity");
                String customerName = rs.getString("customer_name");
                String address = rs.getString("address");
                orders.add(new Order(orderId, itemName, quantity, customerName, address));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return orders;
    }

    // Method to update an order's details
    public boolean updateOrder(int orderId, String itemName, int quantity, String customerName, String address) {
        String query = "UPDATE orders SET item_name = ?, quantity = ?, customer_name = ?, address = ? WHERE order_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, itemName);
            pstmt.setInt(2, quantity);
            pstmt.setString(3, customerName);
            pstmt.setString(4, address);
            pstmt.setInt(5, orderId);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;  // Return true if the update was successful
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;  // Return false if the update failed
    }

    // Method to delete an order by its ID
    public boolean deleteOrder(int orderId) {
        String query = "DELETE FROM orders WHERE order_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, orderId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;  // Return true if the delete was successful
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;  // Return false if the delete failed
    }

    // Method to add a new order
    public boolean addOrder(String itemName, int quantity, String customerName, String address) {
        String query = "INSERT INTO orders (item_name, quantity, customer_name, address) VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, itemName);
            pstmt.setInt(2, quantity);
            pstmt.setString(3, customerName);
            pstmt.setString(4, address);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;  // Return true if the insertion was successful
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;  // Return false if the insertion failed
    }
}

