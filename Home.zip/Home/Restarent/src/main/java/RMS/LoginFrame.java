package RMS;

import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends Frame {
    TextField usernameField, passwordField;
    Button loginButton;

    public LoginFrame() {
        setTitle("Login");
        setSize(300, 200);
        setLayout(new FlowLayout());

        // Labels and text fields for user input
        add(new Label("Username:"));
        usernameField = new TextField(20);
        add(usernameField);

        add(new Label("Password:"));
        passwordField = new TextField(20);
        passwordField.setEchoChar('*');
        add(passwordField);

        loginButton = new Button("Login");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Handle login logic here
                // For now, just show success message
                System.out.println("User Logged In: " + usernameField.getText());
                new HomeFrame();  // Open the HomeFrame after successful login
                dispose();  // Close LoginFrame
            }
        });
        add(loginButton);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new LoginFrame();
    }
}

