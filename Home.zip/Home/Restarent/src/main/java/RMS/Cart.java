package RMS;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    // List to store items in the cart
    private List<CartItem> items;

    public Cart() {
        this.items = new ArrayList<>();
    }

    // Method to add an item to the cart
    public void addItem(CartItem item) {
        items.add(item);
    }

    // Method to remove an item from the cart
    public void removeItem(int itemId) {
        items.removeIf(item -> item.getItemId() == itemId);
    }

    // Method to update the quantity of an item in the cart
    public void updateItemQuantity(int itemId, int quantity) {
        for (CartItem item : items) {
            if (item.getItemId() == itemId) {
                item.setQuantity(quantity);
            }
        }
    }

    // Method to calculate the subtotal of the cart
    public double calculateSubtotal() {
        double subtotal = 0.0;
        for (CartItem item : items) {
            subtotal += item.getItemPrice() * item.getQuantity();
        }
        return subtotal;
    }

    // Method to calculate the total price of the cart, including tax and discount
    public double calculateTotal(double taxRate, double discountRate) {
        double subtotal = calculateSubtotal();
        double tax = subtotal * taxRate / 100;
        double discount = subtotal * discountRate / 100;
        return subtotal + tax - discount;
    }

    // Method to get the list of items in the cart
    public List<CartItem> getItems() {
        return items;
    }

    // Method to clear the cart
    public void clearCart() {
        items.clear();
    }

    // Inner class to represent an item in the cart
    public static class CartItem {
        private int itemId;
        private String itemName;
        private double itemPrice;
        private int quantity;

        public CartItem(int itemId, String itemName, double itemPrice, int quantity) {
            this.itemId = itemId;
            this.itemName = itemName;
            this.itemPrice = itemPrice;
            this.quantity = quantity;
        }

        public int getItemId() {
            return itemId;
        }

        public String getItemName() {
            return itemName;
        }

        public double getItemPrice() {
            return itemPrice;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        @Override
        public String toString() {
            return itemName + " - " + quantity + " x $" + itemPrice;
        }
    }

    // Example usage
    public static void main(String[] args) {
        Cart cart = new Cart();

        // Add items to the cart
        cart.addItem(new CartItem(1, "Pizza", 15.0, 2));
        cart.addItem(new CartItem(2, "Burger", 10.0, 3));

        // Calculate the subtotal
        System.out.println("Subtotal: $" + cart.calculateSubtotal());

        // Update the quantity of an item
        cart.updateItemQuantity(1, 3);

        // Calculate the total price (with 8% tax and 10% discount)
        double totalPrice = cart.calculateTotal(8.0, 10.0);
        System.out.println("Total Price (after tax and discount): $" + totalPrice);

        // Display the cart items
        System.out.println("\nCart Items:");
        for (CartItem item : cart.getItems()) {
            System.out.println(item);
        }

        // Remove an item from the cart
        cart.removeItem(2);

        // Display the updated cart items
        System.out.println("\nUpdated Cart Items:");
        for (CartItem item : cart.getItems()) {
            System.out.println(item);
        }

        // Clear the cart
        cart.clearCart();
        System.out.println("\nCart cleared. Items in cart: " + cart.getItems().size());
    }
}

