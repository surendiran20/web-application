package RMS;

import java.awt.*;
import java.awt.event.*;

public class CartFrame extends Frame {
    List cartList;
    Button btnCheckout, btnClose;

    public CartFrame() {
        setTitle("Shopping Cart");
        setSize(400, 300);
        setLayout(new BorderLayout());
       
        cartList = new List();
        cartList.add("Item 1 - $10 - Qty: 2");
        cartList.add("Item 2 - $15 - Qty: 1");
        cartList.add("Item 3 - $7 - Qty: 3");
       
        btnCheckout = new Button("Checkout");
        btnCheckout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Proceeding to checkout...");
            }
        });
       
        btnClose = new Button("Close");
        btnClose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
       
        Panel buttonPanel = new Panel();
        buttonPanel.add(btnCheckout);
        buttonPanel.add(btnClose);
       
        add(cartList, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
       
        setVisible(true);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                dispose();
            }
        });
    }
   
    public static void main(String[] args) {
        new CartFrame();
    }
}
