package RMS;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class AllProductFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    public AllProductFrame() {
        // Frame setup
        setTitle("All Products");
        setSize(600, 400);
        setLocationRelativeTo(null); // Center the window

        // Set up JTable to display products
        String[] columnNames = {"Product ID", "Name", "Description", "Price", "Stock"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0); // Initialize with column names
        JTable table = new JTable(model);

        // Fetch products from the database and populate the table
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/food_order_system", "root", "")) {
            String query = "SELECT * FROM products";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                Object[] row = {
                    rs.getInt("product_id"),
                    rs.getString("name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("stock")
                };
                model.addRow(row); // Add rows to the table model
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Adding the table to a JScrollPane
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Create an instance of AllProductFrame and display it
            AllProductFrame frame = new AllProductFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close application when the window is closed
            frame.setVisible(true);
        });
    }
}