package RMS;

import java.awt.*;
import java.awt.event.*;

public class HomeFrame extends Frame {
    // Define buttons for all the frames
    Button signUpButton, loginButton, addProductButton, allProductButton;
    Button manageProductButton, orderButton, viewOrdersButton, statisticsButton;

    public HomeFrame() {
        setTitle("Home - Food Order System");
        setSize(400, 500);
        setLayout(new GridLayout(4, 2, 10, 10)); // Improved layout for better alignment

        // Create buttons
        signUpButton = new Button("Sign Up");
        loginButton = new Button("Login");
        addProductButton = new Button("Add Product");
        allProductButton = new Button("All Products");
        manageProductButton = new Button("Manage Products");
        orderButton = new Button("Order");
        viewOrdersButton = new Button("View Orders");
        statisticsButton = new Button("Statistics");

        // Set up event listeners for buttons
        signUpButton.addActionListener(e -> openFrame(new SignUpFrame()));
        loginButton.addActionListener(e -> openFrame(new LoginFrame()));
        addProductButton.addActionListener(e -> openFrame(new AddProductFrame()));
        allProductButton.addActionListener(e -> openFrame(new AllProductFrame()));
        manageProductButton.addActionListener(e -> openFrame(new ManageProductFrame()));
        orderButton.addActionListener(e -> openFrame(new OrderFrame()));
        viewOrdersButton.addActionListener(e -> openFrame(new ViewOrdersFrame()));
        statisticsButton.addActionListener(e -> openFrame(new StatisticsFrame()));

        // Add buttons to the frame
        add(signUpButton);
        add(loginButton);
        add(addProductButton);
        add(allProductButton);
        add(manageProductButton);
        add(orderButton);
        add(viewOrdersButton);
        add(statisticsButton);

        // Close the application when window is closed
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });

        // Center the frame on screen
        setLocationRelativeTo(null);

        setVisible(true);
    }

    private void openFrame(Frame frame) {
        frame.setVisible(true);
        dispose(); // Close the current frame only after opening the new one
    }

    public static void main(String[] args) {
        new HomeFrame();  // Launch the HomeFrame
    }
}
