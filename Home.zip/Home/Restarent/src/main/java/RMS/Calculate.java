package RMS;

public class Calculate {

    // Method to calculate the total price of an order
    public double calculateTotalPrice(double itemPrice, int quantity, double taxRate, double discountRate) {
        double subtotal = itemPrice * quantity; // Calculate the subtotal (price * quantity)
        double taxAmount = subtotal * taxRate / 100; // Calculate tax based on the rate
        double discountAmount = subtotal * discountRate / 100; // Calculate discount based on the rate

        // Total price = subtotal + tax - discount
        double totalPrice = subtotal + taxAmount - discountAmount;

        return totalPrice;
    }

    // Method to calculate the subtotal (price * quantity)
    public double calculateSubtotal(double itemPrice, int quantity) {
        return itemPrice * quantity;
    }

    // Method to calculate the tax for an order
    public double calculateTax(double subtotal, double taxRate) {
        return subtotal * taxRate / 100;
    }

    // Method to calculate the discount for an order
    public double calculateDiscount(double subtotal, double discountRate) {
        return subtotal * discountRate / 100;
    }

    // Example usage of the Calculate class
    public static void main(String[] args) {
        // Example data: Item price = 20.0, Quantity = 3, Tax rate = 8%, Discount rate = 10%
        double itemPrice = 20.0;
        int quantity = 3;
        double taxRate = 8.0; // 8% tax
        double discountRate = 10.0; // 10% discount

        // Create an instance of Calculate
        Calculate calculate = new Calculate();

        // Calculate the total price
        double totalPrice = calculate.calculateTotalPrice(itemPrice, quantity, taxRate, discountRate);

        // Print out the result
        System.out.println("Item Price: " + itemPrice);
        System.out.println("Quantity: " + quantity);
        System.out.println("Subtotal: " + calculate.calculateSubtotal(itemPrice, quantity));
        System.out.println("Tax: " + calculate.calculateTax(calculate.calculateSubtotal(itemPrice, quantity), taxRate));
        System.out.println("Discount: " + calculate.calculateDiscount(calculate.calculateSubtotal(itemPrice, quantity), discountRate));
        System.out.println("Total Price (after tax and discount): " + totalPrice);
    }
}

