package RMS;

import java.awt.*;
import java.awt.event.*;

public class SignUpFrame extends Frame {
    TextField usernameField, passwordField, emailField;
    Button signUpButton;

    public SignUpFrame() {
        setTitle("Sign Up");
        setSize(300, 300);
        setLayout(new FlowLayout());

        // Labels and text fields for user input
        add(new Label("Username:"));
        usernameField = new TextField(20);
        add(usernameField);

        add(new Label("Password:"));
        passwordField = new TextField(20);
        passwordField.setEchoChar('*');
        add(passwordField);

        add(new Label("Email:"));
        emailField = new TextField(20);
        add(emailField);

        signUpButton = new Button("Sign Up");
        signUpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Handle sign-up logic here
                // For now, just show success message
                System.out.println("User Signed Up: " + usernameField.getText());
                new HomeFrame();  // Open the HomeFrame after successful signup
                dispose();  // Close SignUpFrame
            }
        });
        add(signUpButton);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new SignUpFrame();
    }
}
